import React, { useState, useEffect } from 'react';

function ItemComponent() {
    const [items, setItems] = useState([]);
    const [apiResult, setApiResult] = useState('');

    useEffect(() => {
        fetch('http://localhost:5000/api/members') // Make sure this matches the Flask API route
            .then(response => response.json())
            .then(data => setItems(data))
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    const fetchNodeApi = () => {
        fetch('http://localhost:3001/api/data') // Node.js API endpoint
            .then(response => response.json())
            .then(data => setApiResult(data.message))
            .catch(error => console.error('Error fetching Node.js API:', error));
    };

    return (
        <div>
            <button onClick={fetchNodeApi}>Fetch Node.js API</button>
            <button onClick={() => console.log(items)}>Log Items</button>
            <h1>Members List</h1>
            <ul>
                {items.map(item => (
                    <li key={item.id}>{item.name}</li>
                ))}
            </ul>
            <div>
                <p>Node.js API Result: {apiResult}</p>
            </div>
        </div>
    );
}

export default ItemComponent;
